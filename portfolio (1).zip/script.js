/* ===== EDIT YOUR DETAILS HERE ===== */
const CONFIG = {
  percentage: null,              // e.g. 85  (null = shows "YOUR PERCENTAGE" placeholder)
  email: "",                     // e.g. "yourname@gmail.com"
  linkedin: "",                  // e.g. "https://www.linkedin.com/in/your-id"
  github: "",                    // e.g. "https://github.com/your-id"
  skills: [["C Programming","Beginner",25],["HTML","Learning",40],["CSS","Learning",40],
           ["JavaScript","Learning",25],["Problem Solving","Developing",35],["Communication","Improving",45]],
  milestones: [["Learning C basics","In progress"],["Learning HTML, CSS & JavaScript","In progress"],
               ["Build my first full website","Planned"],["Develop ScamShield AI prototype","Planned"]],
  projectProgress: [["ScamShield AI (concept)",10]],
  goals: ["Become a skilled software developer","Build real projects","Keep learning every day"],
  plannedFeatures: ["Payment message checker","Warning-sign guide","Simple risk indicator","User-friendly interface"]
};
/* =================================== */
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const wait=ms=>new Promise(r=>setTimeout(r,ms));
const ease=t=>1-Math.pow(1-t,3);

function countTo(el,to,dur=1500){const t0=performance.now();(function f(n){const p=Math.min((n-t0)/dur,1);el.textContent=Math.round(to*ease(p));if(p<1)requestAnimationFrame(f)})(t0)}

/* Loading */
const texts=[[0,"Preparing Your Experience..."],[40,"Entering Madhumitha's World..."],[80,"Almost Ready..."]];
function load(){return new Promise(res=>{const t0=performance.now(),D=3800;(function f(n){
  const p=Math.min((n-t0)/D,1),v=Math.round(100*ease(p));
  $('#lp').textContent=v;$('#lb').style.width=v+'%';
  texts.forEach(([a,t])=>{if(v>=a)$('#lt').textContent=t});
  p<1?requestAnimationFrame(f):res()})(t0)})}

/* Greetings */
const greets=["HI","வணக்கம்","SALUT","HOLA","こんにちは","안녕하세요","HALLO","CIAO","你好","नमस्ते"];
async function greet(){
  const g=$('#gw');
  for(const w of greets){
    g.className='';g.innerHTML='';
    [...w].forEach((ch,i)=>{const s=document.createElement('span');s.textContent=ch;s.style.animationDelay=i*70+'ms';g.appendChild(s)});
    await wait(900+w.length*70);g.classList.add('out');await wait(500);
  }
  g.remove();$('#gname').classList.remove('hidden');await wait(1400);
  $('#gwel').classList.remove('hidden');await wait(1000);$('#enter').classList.remove('hidden');
}

/* Navigation */
let current='home',stack=[];
function show(id,push=true){
  if(id===current)return;
  if(push)stack.push(current);
  $('#'+current).classList.remove('on');current=id;
  $('#'+id).classList.add('on');$('#'+id).scrollTop=0;
  $$('.nv').forEach(b=>b.classList.toggle('on',b.dataset.go===id||(id==='detail'&&b.dataset.go==='projects')));
  if(id==='skills')setTimeout(()=>$$('.meter i').forEach(m=>m.style.width=m.dataset.w+'%'),50);
  if(id==='performance')setTimeout(perf,300);
}
$$('[data-go]').forEach(b=>b.onclick=()=>show(b.dataset.go));
$('#homeBtn').onclick=()=>{stack=[];show('home',false)};
$('#backBtn').onclick=()=>{if(stack.length)show(stack.pop(),false)};

/* Build content */
CONFIG.skills.forEach(([n,l,v])=>{$('#skillGrid').insertAdjacentHTML('beforeend',`<div class="card sk c"><b>${n}</b><em>${l}</em><div class="meter"><i data-w="${v}"></i></div></div>`)});
CONFIG.plannedFeatures.forEach(f=>$('#planned').insertAdjacentHTML('beforeend',`<li>${f} <em>(planned)</em></li>`));
CONFIG.milestones.forEach(([m,s])=>$('#ms').insertAdjacentHTML('beforeend',`<li>${s==='Planned'?'○':'◐'} ${m} <span class="note">— ${s}</span></li>`));
CONFIG.projectProgress.forEach(([n,v])=>$('#pp').insertAdjacentHTML('beforeend',`<p>${n} — ${v}%</p><div class="meter"><i data-w="${v}" style="width:${v}%"></i></div>`));
CONFIG.goals.forEach(g=>$('#goals').insertAdjacentHTML('beforeend',`<li>★ ${g}</li>`));
/* mark dynamically added cards as collapsible */
$$('#app .card,#app .meter').forEach(e=>e.classList.add('c'));

/* Percentage HUD */
function perf(){
  const p=CONFIG.percentage;
  if(typeof p==='number'&&p>=0&&p<=100){
    countTo($('#pv'),p);$('#pl').textContent='YOUR PERCENTAGE';
    $('#pr').style.strokeDashoffset=339.3*(1-p/100);
    $('#lvl').textContent='LEVEL '+(Math.floor(p/10)+1);
  }else{$('#pv').textContent='--';$('#lvl').textContent='LEVEL --'}
}

/* Contact */
(function(){
  const set=(id,url,mail)=>{const a=$(id);
    if(url){a.href=mail?'mailto:'+url:url}
    else{a.classList.add('off');a.onclick=e=>{e.preventDefault();$('#cnote').textContent='Add your '+a.textContent+' details in script.js (CONFIG) to activate this button.'}}};
  set('#mail',CONFIG.email,true);set('#li',CONFIG.linkedin);set('#gh',CONFIG.github);
})();

/* DO NOT PRESS: collapse + restore (visual only) */
let busy=false;
async function collapse(){
  if(busy)return;busy=true;
  document.body.classList.add('freeze');await wait(600);
  const cx=innerWidth/2,cy=innerHeight/2;
  $$('#app .c').forEach(e=>{const r=e.getBoundingClientRect();
    e.style.setProperty('--dx',(cx-r.left-r.width/2)+'px');e.style.setProperty('--dy',(cy-r.top-r.height/2)+'px');e.classList.add('suck')});
  $('#flash').classList.remove('on');void $('#flash').offsetWidth;$('#flash').classList.add('on');
  $('#app').classList.remove('unfold');$('#app').classList.add('fold');
  await wait(2300);$('#dot').classList.add('on');
  await wait(900);const v=$('#void');v.classList.add('show');await wait(50);v.classList.add('vis');
}
async function restore(){
  const v=$('#void');v.classList.remove('vis');await wait(900);v.classList.remove('show');
  $('#dot').classList.remove('on');
  const app=$('#app');app.classList.remove('fold');app.classList.add('unfold');
  $$('#app .suck').forEach(e=>e.classList.remove('suck'));
  await wait(1700);app.classList.remove('unfold');document.body.classList.remove('freeze');busy=false;
}
$('#dnp').onclick=collapse;$('#restore').onclick=restore;

/* Start */
(async function(){
  await load();
  $('#loader').style.opacity=0;await wait(800);$('#loader').classList.add('hidden');
  $('#greet').classList.remove('hidden');greet();
})();
$('#enter').onclick=async()=>{
  $('#greet').style.opacity=0;await wait(800);$('#greet').classList.add('hidden');
  $('#app').classList.remove('hidden');await wait(50);$('#home').classList.add('on');
  $$('.nv').forEach(b=>b.classList.remove('on'));
};
